import speech_recognition as s
import pyttsx3
import sys



test_val=""
engine = pyttsx3.init('sapi5')
voices=engine.getProperty('voices')

engine.setProperty('voice', voices[1].id)
#file_=open("A:\\savvy\\savvy_pro_file\\tetsing\\predicted.txt","r")
#file_length=file_.read()
#if(len(file_length)!=0):
#    file0=open("A:\\savvy\\savvy_pro_file\\tetsing\\predicted.txt","w")

file1=open("A:\\savvy\\savvy_pro_file\\tetsing\\predicted.txt","a")
i=0
def testing_input():
    
    rec=s.Recognizer()
    with s.Microphone() as source:
        s1="Waiting for your Command"
        print(s1)
        rec.pause_threshold =1
        audio=rec.listen(source,phrase_time_limit=5)
    try:
        print("Understanding!!")
        comand=rec.recognize_google(audio,language="en-is")
        #comand=rec.adjust_for_ambient_noise(comand)
        print("You said :- ",comand)
        i=i+1
        name="audio"+i+".wav"
        with open(name,'wb') as f:
            f.write(audio.get_wav_data())
        if(comand!="exit"):

            file1.writelines(comand+".\n")
            print("Got here")
            
            testing_input()
        if(comand=="exit"):
            file1.close()
            sys.exit()

    except Exception as e :
        #sav("Didn't get that one ")
        
        return testing_input()
    return comand

def testing():
    #WER
    file1=open("A:\\savvy\\savvy_pro_file\\tetsing\\predicted.txt","r")
    predicted_val=file1.read()
    #testing_input()
    file2=open("A:\\savvy\\savvy_pro_file\\tetsing\\actual.txt","r")

    actual_val=file2.read()
    #print(actual_val)
    actual_val=actual_val.replace(",","")
    actual_val=actual_val.replace("?","")
    actual_val=actual_val.replace("!","")
    actual_val=actual_val.replace(":","")
    actual_val=actual_val.replace("'","")
    
    

    from jiwer import wer

    error=wer(actual_val,predicted_val)
    print("The WER error is :- ",error)

    accuracy=1-error
    accuracy=accuracy*100
    print("Accuracy of SR wiht pyttssx3 is ",accuracy,"%")
#testing_input()

testing()