import os 
import openai
from dotenv import load_dotenv
s=os.path.abspath("api_savvy.txt")

#print("PATH",s)
#API KEY
FileOpenAi = open(s,'r')
apikey = FileOpenAi.read()
FileOpenAi.close()

from dotenv import load_dotenv
import openai

openai.api_key = apikey

load_dotenv()
completion = openai.Completion()

chat_log_template = '''You : Hello, who are you?
Savvy : I am doing great. How can I help you today?
'''

def Reply(question, chat_log=None):
    if chat_log is None:
        chat_log = chat_log_template
    prompt = f'{chat_log}You : {question}\nSavvy :'
    response = completion.create(
        prompt=prompt, engine="davinci", stop=['\nYou'], temperature=0.9,
        top_p=1, frequency_penalty=0, presence_penalty=0.6, best_of=1,
        max_tokens=150)
    answer = response.choices[0].text.strip()
    return answer

print(Reply("Which is good chatgpt or google"))