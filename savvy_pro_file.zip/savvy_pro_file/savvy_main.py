import sys
import pyttsx3
import speech_recognition as s
import datetime as dt
import os 
import requests
import pywhatkit as pk
import webbrowser
from requests import get
from pynput.keyboard import Controller as ck
import cv2
import pyautogui
from PyPDF2 import PdfReader as pf
import time
import wikipedia
import keyboard
import psutil



from ecapture import ecapture as ec
import smtplib
import winshell
#from api import Reply



#import dependencies 



#
time_n=dt.datetime.now()
time_n=str(time_n)
time_now=(dt.datetime.now().strftime("%H-%M"))
li=(time_now.split("-"))
a=int(li[0])
b=int(int(li[1])+2)
#print(time_now)
#print(Users)

Users={"Name":"Password"}

engine = pyttsx3.init('sapi5')
voices=engine.getProperty('voices')

engine.setProperty('voice', voices[1].id) 




def voice_check():
    for voice in voices:
        print(voice, voice.id)
        engine.setProperty('voice', voice.id)
        engine.say("Hi its me ")
        engine.runAndWait()
        engine.stop()


#speak
def sav(audio):
    engine.say(audio)
    print(audio)
    engine.runAndWait()
m=0
#get input
def v_input():
    m=0
    rec=s.Recognizer()
    with s.Microphone() as source:
        s1="Waiting for your Command"
        print(s1)
        rec.pause_threshold =1
        audio=rec.listen(source,phrase_time_limit=5)
        
    try:
        print("Understanding!!")
        comand=rec.recognize_google(audio,language="en-in")
        #comand=rec.adjust_for_ambient_noise(comand)
        print("You said :- ",comand)
        m=m+1
        name="audio"+str(m)+".wav"
        with open(name,'wb') as f:
            f.write(audio.get_wav_data())

    except Exception as e :
        #sav("Didn't get that one ")
        
        return v_input()
    return comand

def in_inp():
    rec=s.Recognizer()
    with s.Microphone() as source:
        s1="Waiting for Command"
        print(s1)
        rec.pause_threshold =1
        audio=rec.listen(source,phrase_time_limit=5)
    try:
        print("Recognizing")
        comand=rec.recognize_google(audio,language="en-in")
        print("Command Opted ",comand)
    except Exception as e :
        #sav("Cannot Understand")
        comand=""

        return in_inp()
        
    return comand

import subprocess

def process_exists(process_name):
    call = 'TASKLIST', '/FI', 'imagename eq %s' % process_name
    # use buildin check_output right away
    output = subprocess.check_output(call).decode()
    # check in last line for process name
    last_line = output.strip().split('\r\n')[-1]
    # because Fail message could be translated
    return last_line.lower().startswith(process_name.lower())
    
def type_on():
      #content to be written
    time_now=int(dt.now().strftime("%H-%M"))

def new_us():
#from user import *
    sav("Creating new user")

    sav("What should i call you")
    user_name=v_input()
    user_str="Hey"+user_name+"Please set a password"
    sav(user_str)
    passwd=v_input()

    Users[user_name]=passwd
    return "User created"

def get_news(a):
    
    url="http://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=1140cca0446042d0ae3372762d564a5f"
    
    main_page=requests.get(url).json()
    
    art=main_page["articles"]
    a=int(a)
    top=[]
    for i in art:
        top.append(i["title"])
    for j in range(1,a+1):
        s="News number "+str(j)+" is  "+top[j]
        sav(s)

def pd_read(f_name):
    data=open(f'{f_name}','rb')
    pdfread=pf(data)
    page=pdfread.numPages
    sav("The file contains ",page," Pages")
    sav("ENter page number to be read")
    p_no=int(v_input())
    read=pdfread.getPage(p_no)
    out=read.extractText()
    sav(out)

def file_search(name):
    res=os.path.dirname(name)
    print(name)
    if(res):
        return res
    else :
        return "No such file exist"


def sendEmail(to, content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()

    # Enable low security in gmail
    server.login('rushikeshkadam2420@gmail.com', 'rqwtlanrqclzyaza')
    server.sendmail('rushikeshkadam2420@gmail.com', to, content)
    server.close()

def ytauto():
    sav("What do you want to do ?")
    task=in_inp()
    if "pause" in task:
        keyboard.press("space bar")

    elif "replay video" in task:
        keyboard.press("space bar")
    elif "mute" in task:
        keyboard.press("m")
    elif "skip" in task:
        keyboard.press("l")
    elif "back" in task:
        keyboard.press("j")
    elif "full screen" in task:
        keyboard.press("f")
    elif "full screen" in task:
        keyboard.press("f")
    elif "mini player" in task:
        keyboard.press("i")
    




def execution():
        print("here i  am")
        sav("Hi \nI am Savvy")
        sav("Welcome User")
        i=0
        while True:
            
            
                
            task=v_input().lower()  
            
            if "open notepad"in task:
                not_path="C:\\Windows\\notepad.exe"
                if os.path.exists(not_path):
                    os.startfile(not_path)
                else:
                    sav("Specify Drive")
                    Drive=v_input()
                    new_path=Drive+":\\Windows\\notepad.exe"
                    print(new_path)
                    os.startfile(new_path)

            elif "close notepad" in task:
                os.system("taskkill /f /im notepad.exe")
                sav("Notepad closed")

            elif "open command prompt" in task:
                os.system("start cmd")

            elif "close command prompt" in task:
                os.system("taskkill /f /im cmd.exe")

            elif " my ip" in task :
                res=get('https://api.ipify.org').text
                sav(res)

            elif "send a message" in task:
                whatname = {"Harsh": "+918329965886", "Pranay":"+919373985466","Shubham":"+918668983515","Rushikesh":"+919730344047"}
                #print("Hl")
                sav("What is the message ")
                msg=v_input()
                sav("Whom should i send ?")
                name = v_input()
                if name in whatname.keys():
                    pk.sendwhatmsg(whatname[name],msg,a,b)
                else:
                    sav("name not found in your contacts, please provide contact number")
                    num = v_input()
                    num = "+91" + num
                    pk.sendwhatmsg(num,msg,a,b)
            

            elif "time" in task:
                sav(time_now)
                print(time_n)
            
            
            elif "open ms word" in task :
                not_path="C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE"
                if os.path.exists(not_path):
                    os.startfile(not_path)
                else:
                    sav("Specify Drive")
                    Drive=v_input()
                    new_path=Drive+":\\Windows\\Word.exe"
                    print(new_path)
                    os.startfile(new_path)

            elif "close ms word" in task:
                os.system("taskkill /f /im WINWORD.EXE")
                sav("MS Word closed")

            elif "open powerpoint" in task :
                not_path="C:\\Program Files\\Microsoft Office\\root\\Office16\\POWERPNT.EXE"
                if os.path.exists(not_path):
                    os.startfile(not_path)
                else:
                    sav("Specify Drive")
                    Drive=v_input()
                    new_path=Drive+":\\Windows\\PowerPoint.exe"
                    print(new_path)
                    os.startfile(new_path)

            elif "close powerpoint" in task:
                os.system("taskkill /f /im POWERPNT.EXE")
                sav("Powerpoint closed")
            
            elif "start camera" in task :
                #sav("I know you look good !! but for your assurance let me open the Camera")
                sav("Press Space bar to close the camera")
                cap=cv2.VideoCapture(0)
                ch=1
                while ch==1:
                    ret, img=cap.read()
                    cv2.imshow('webcam',img)
                    k=cv2.waitKey(30)
                    if k==32:
                        break
                        
                    
                    
                cap.release()
              
                cv2.destroyAllWindows()
            
            #elif "close notepad" in task :
            #    os.system("taskkill /f /im notepad.exe")
            #    sav("Notepad has been closed")

            elif "close comand prompt" in task:
                os.system("taskkill /f /im cmd")
                sav("Command prompt closed")
            
            elif "shutdown pc" in task :
                os.system("shutdown /s /t 4")
            
            elif "restart pc" in task :
                os.system("shutdown /r /t 4")
                
            elif "switch window" in task or "change window" in task :
                pyautogui.keyDown("alt")
                pyautogui.keyDown("tab")
                time.sleep(1)
                pyautogui.keyUp("alt")

            elif "new today" in task:
                #sav("How many requests")
                #n=v_input()
                #if(int(n)):
                get_news(3)
                #else:
                #    sav("Invalid input")
                

            elif  "take screenshot" in task:
                sav("Under what name should i save the File")
                file_name=v_input().lower()
                sav("Taking the screen shot ")
                time.sleep(2)
                img=pyautogui.screenshot()
                img.save(f"{file_name}.png")
                sav("Photo saved")
                
            elif "read pdf" in task:
                f_n=sav()
                pd_read()
            
            elif "search"and  "file"in task:
                sav("What is the name of the file")
                f1=v_input()
                sav("What is the file format")
                f2=v_input().lower()
                sav(f"Searching for file {f1}.{f2}")
                f3=f1+"."+f2
                path=file_search(f3)
                sav(path)

            elif "battery" in task :
                import psutil
                amount=psutil.sensors_battery()
                a_percent=amount.percent
                sav(f"Percentage Power of the system is {a_percent}")
            
            elif "open youtube" in task :
            
                webbrowser.open_new_tab('https://www.youtube.com')
                sav("Do you want me to help you with further tasks")
                ch=in_inp()
                if(ch.lower()=="okay"):
                    ytauto()

                else :
                    sav("Okay Sir")

            elif "youtube search" in task:
                task=task.lower().replace("youtube search","")
                web='https://www.youtube.com/results?search_query='+task
                print(web)
                webbrowser.open(web)

            elif "google search" in task:
                task=task.replace("google search","")
                pk.search(task)
                sav("Done")

            elif "website" in task:
                sav("Which website sir ?")
                web=v_input()
                web1=f'https://www.{web}.com'
                webbrowser.open_new_tab(web1)

            elif "wikipedia search" in task:
                sav("Searching")
                try:
                    task=task.replace("wikipedia search","")
                    summ=wikipedia.summary(task,2)
                    sav(f"According to wikipedia{summ}")
                except Exception as e:
                    sav("couldnt find resembling information")
                
            
            elif "pause video" in task:
                keyboard.press("k")

            elif "play video" in task:
                keyboard.press("k")
            elif "mute" in task:
                keyboard.press("m")
            elif "forward" in task:
                keyboard.press("l")
            elif "back" in task:
                keyboard.press("j")
            elif "full screen" in task:
                keyboard.press("f")
            
            elif "mini screen"  in task:
                keyboard.press("i")
            
            elif "next video" in task:
                keyboard.press("shift + n")
            
            elif "previous video" in task :
                keyboard.press("shift + p")
            
            elif "search video" in task :
                sav("Which video should i open")
                name=str(v_input())

                pk.playonyt(name)
            
            elif "help me" in task:
                from pywikihow import search_wikihow
                sav("Savvy is always here to Help you")
                sav("What can i help you with")
                what=v_input()
                try:
                    if "exit" in what:
                        sav("Help requested withdrawn")
                        break
                    else:
                        max_res=1
                        what_help=search_wikihow(what,max_res)
                        assert len(what_help)==1
                        what_help[0].print()
                        sav(what_help[0].summary)
                except Exception as e:
                        sav("Sorry,Savvy is not able to help you with this")
            

            elif "delete recycle bin" in task:
                winshell.recycle_bin().empty(
                    confirm=True, show_progress=False, sound=True
                )
                #keyboard.press("enter")
                sav("Done")

        #To find any location on map       

            elif 'show location on map' in task:
                sav('Which location you want to see?')
                location=v_input()
                url = 'https://google.nl/maps/place/' + location + '/&amp;'
                webbrowser.get().open(url)
                sav('Here is location' + location)

            #To take a photo and save it directly
            elif "camera" in task or "take a photo" in task:
                ec.capture(0, "Savvy Camera ", "img.jpg")

            #To create a file and write text in it directly and save it   
            elif "write a note" in task:
                sav("What should i write, sir")
                file =open("myfile.txt", "a")
                note ="\n"+v_input()+"."
                file.write(note)
                file.close()

            #To display files and text written in that files   
            elif "read note" in task:
                
                file = open("myfile.txt", 'r')
                
                ch=str(file.read())
                if (len(ch)>0):
                    sav("Reading note")
                    print(ch)
                    sav(ch)
                else :
                    sav("No pending notes")

            elif "clear note" in task :
                file=open("myfile.txt",'w')
                file.close()
                sav("note has been cleared")

            #To send a mail directly to anyone
            elif 'send mail' in task:
                try:
                    sav("What should I say?")
                    content = v_input()
                    sav("Whom i send?")  
                    to = v_input()+"@gmail.com"
                    to2= to.replace(" ","")
                    ch="Receipents mail address is "+to2.lower()
                    sav(ch)
                    sendEmail(to2, content)
                    sav("Email has been sent !")
                except Exception as e:
                    print(e)
                    sav("I am not able to send this email")

            #To open shopping website like amazon directly        
            elif 'open amazon' in task:
                    webbrowser.open("amazon.in")
            elif 'how are you' in task:
                sav("I am fine and ready to work for you.")

            elif 'what is your name' in task:
                sav("it's savvy your virtual assistant")
            
            elif "who invented you" in task :
                sav("Founding fathers of Savvy are Harsh , Shubham , Rushikesh , Pranay")

            elif "tell me today's schedule" in task:
                sav("Check out to-do list for schedule")

            elif 'what can you do for me' in task:
                sav("I can do all tasks a assistant can do like playing music, opening apps, etc.")

                
            elif "press enter" in task:
                pyautogui.press('enter')
 

            

            elif "start typing" in task:
                query = ""
                kb_keys = {"tab space":'\t',"exclamation":'!',"double quote":'"',"hash":'#',"dollar":'$',"percent":'%',"ampersand":'&',"single quote":"'","open parenthesis": '(',
                        "close parenthesis": ')', "asterisk": '*',"plus":'+', "comma": ',', "hyphen":"-","minus":"-","full stop":".","dot":".","forward slash" :'/',"slash":"/",
                        "back slash": "\\","backward slash":"\\","colon":":","semi colon":";","less than":"<","equal to": '=',"greater than": '>',"question mark": '?',
                            "open square bracket": '[',"close square bracket":  ']',"caret": '^',"underscore": '_', "backtick":'`',"open curly bracket": '{',
                            "bar": '|',"close curly bracket": '}', "tilde":'~' }

                kb_num = {"zero":'0',"one": '1',"two": '2',"three": '3',"four": '4',"five": '5',"six": '6',"seven": '7',"eight": '8', "nine": '9'}

                sav("what would you like to write?")

                while "close typing" not in query.lower():
                    query = v_input()
                    if "close typing" in query :
                        sav("Stopped typing")
                        break

                    elif "select all" in query:
                        pyautogui.hotkey('ctrl', 'a')

                    elif "new line" in query or "press enter" in query:
                        pyautogui.press('enter')

                    elif "backspace" in query:
                        pyautogui.press('backspace')

                    elif "clear line" in query:
                        with pyautogui.hold('shift'):
                            pyautogui.press('home')
                        pyautogui.press('backspace')

                    elif "clear word" in query:
                        pyautogui.hotkey('ctrl', 'shift', 'left')
                        pyautogui.press('backspace')

                    elif "undo" in query:
                        pyautogui.hotkey('ctrl', 'z')

                    elif "redo"in query:
                        pyautogui.hotkey('ctrl', 'y')

                    else:
                        w_list = query.split(" ")
                        l_index = len(w_list)
                        index = 0
                        while index<l_index:
                            #print(index)
                            if w_list[index] == "num" or w_list[index] == "nam" or w_list[index] == "number":
                                if w_list[index+1] in kb_num.values():
                                    w_list[index] = ""
                                elif w_list[index+1] in kb_num.keys():
                                    w_list[index] = ""
                                    w_list[index+1] = kb_num[w_list[index+1]]

                            if w_list[index] == "symbol":                    
                                if w_list[index+1] in kb_keys.keys():
                                    w_list[index+1] = kb_keys[w_list[index+1]]
                                    w_list[index] = ""
                                elif index+2 <= len(w_list)-1 and w_list[index+1]+" "+w_list[index+2] in kb_keys.keys():
                                        w_list[index+1] = kb_keys[w_list[index+1]+" "+w_list[index+2]]
                                        w_list[index] = ""
                                        l_index -=1
                                        w_list.pop(index+2)
                                elif index+3 <= len(w_list)-1 and w_list[index+1]+" "+w_list[index+2]+" "+w_list[index+3] in kb_keys.keys():
                                        w_list[index+1] = kb_keys[w_list[index+1]+" "+w_list[index+2]+" "+w_list[index+3]]
                                        w_list[index] = ""
                                        l_index -=2
                                        w_list.pop(index+2)                                    
                                        w_list.pop(index+2)
                            index +=1

                        query1 = " ".join(w_list)

                        pyautogui.typewrite(" "+query1)
            
            elif 'who is' in task:
                person = task.replace('who is', '')
                info = wikipedia.summary(person,1)
                #print(info)
                sav(info)

            elif 'what is' in task:
                know = task.replace('what is', '')
                info = wikipedia.summary(know,1)
                #print(info)
                sav(info)
                
                
            elif 'how to' in task:
                know = task.replace('how to', '')
                info = wikipedia.summary(know,2)
                #print(info)
                sav(info) 

            elif "close tab" in task:
                keyboard.press("ctrl + w")

            elif "reopen tab" in task :
                keyboard.press("ctrl + shift + t")

            elif "change tab" in task:
                keyboard.press("ctrl + 9")

            elif "close chrome window" in task :
                keyboard.press("ctrl + shift + w")

            elif "exit" in task:
                sav("Savvy turning Off")
                sys.exit()


            elif "scroll up" in task or "move up" in task :
                pyautogui.scroll(+725)    
            elif "scroll down" in task or "move down" in task  :
                pyautogui.scroll(-725)
            
            elif "open whatsapp" in task :
                webbrowser.open("https://web.whatsapp.com/")
            #else :
               # sav(Reply(task))
#execution()


