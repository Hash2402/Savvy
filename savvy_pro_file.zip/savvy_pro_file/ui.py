import sys
import pyttsx3
import speech_recognition as s
import datetime as dt
import os 
import requests
import pywhatkit as pk
import webbrowser
from requests import get
from pynput.keyboard import Controller as ck
import cv2
import pyautogui
from PyPDF2 import PdfReader as pf
import time
import wikipedia
import keyboard

from PyQt5 import QtWidgets,QtCore,QtGui
from PyQt5.QtCore import QTime,QTimer,QDate,Qt
from PyQt5.QtGui import QMovie
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUiType
import savvy_main
from savvy_ui import Ui_MainWindow

class MainThread(QThread):
    def __init__(self):
        super(MainThread,self).__init__()
    
    def run(self):
        print("Done")
        savvy_main.execution()
        print("always")

start_exe=MainThread()
class Ui_start(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui=Ui_MainWindow()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.executingtask)
        self.ui.pushButton_2.clicked.connect(self.close)


    def executingtask(self):
        self.ui.movie =QtGui.QMovie("Gif/Jarvis_Gui (1).gif")        
        self.ui.gif.setMovie(self.ui.movie)
        self.ui.movie.start()

        self.ui.movie =QtGui.QMovie("Gif/2RNb.gif")        
        self.ui.label.setMovie(self.ui.movie)
        self.ui.movie.start()

        self.ui.movie =QtGui.QMovie("Gif/g1.gif")        
        self.ui.label_2.setMovie(self.ui.movie)
        self.ui.movie.start()

        self.ui.movie =QtGui.QMovie("Gif/initial.gif")        
        self.ui.label_3.setMovie(self.ui.movie)
        self.ui.movie.start()

        self.ui.movie =QtGui.QMovie("Gif/Earth_Template.gif")        
        self.ui.label_4.setMovie(self.ui.movie)
        self.ui.movie.start()

        start_exe.start()


app=QApplication(sys.argv)
exec=Ui_start()
exec.show()
exit(app.exec_())